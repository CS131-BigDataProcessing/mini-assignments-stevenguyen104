# About the package
This package provides a function to validate columns in the Crime dataset (validate_functions.py) and a function to provide the mean and median for the age column (stats_function.py)

# Installation
In order to install this package, use pip:

```bash
pip install
git+https://github.com/stevenguyen104/crime_test.git
